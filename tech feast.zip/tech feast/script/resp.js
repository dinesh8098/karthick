burger=document.querySelector('.burger')
navlist=document.querySelector('.navlist')
right=document.querySelector('.right')
nav=document.querySelector('.nav')


burger.addEventListener('click',()=>{
    navlist.classList.toggle('vision')
    right.classList.toggle('vision')
    nav.classList.toggle('h-nav')

})




