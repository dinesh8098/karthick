 var marker = document.querySelector('#marker')
var item = document.querySelectorAll('.navlist li ')



function indicator(e){
    marker.style.left =e.offsetLeft+'px'
    marker.style.width =e.offsetWidth+'px'
}
item.forEach(link => {
  
    link.addEventListener('mousemove',(e) =>{
        indicator(e.target)
    })
    
})
